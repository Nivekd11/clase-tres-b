import { DynamicColorDirective } from './dynamic-color.directive';

describe('DynamicColorDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicColorDirective();
    expect(directive).toBeTruthy();
  });
});
